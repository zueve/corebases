from .core import database
from .interface import Connection, Database

__version__ = "0.1.0"
